const express = require('express');
const port = 5000;
const env = require('dotenv').config();
const expressLayouts = require('express-ejs-layouts');
const cookieParser = require('cookie-parser');
const bodyParser = require("body-parser");
const session = require('express-session');
const flash = require("connect-flash");
const customMware = require('./config/middleware');
const jwtAuthMiddleware = require('./config/jwtAuthCheck');

const cors = require('cors');

const app = express();
app.use(cookieParser());

app.use(cors());

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.use(expressLayouts);
app.use(express.static('./assets'));

// extract style and scripts from sub pages into the layout
app.set('layout extractStyles', true);
app.set('layout extractScripts', true);

// set up the view engine
app.set('view engine', 'ejs');
app.set('views', './views');

const oneDay = 1000 * 60 * 60 * 24;
app.use(session({
    name: 'pailogs',
    secret: process.env.SESSION_SECRET,
    saveUninitialized:false,
    cookie: {
        maxAge: (1000 * 60 * 100)
    },    resave: false
}));
app.use(flash());
app.use([
    customMware.setFlash,
    customMware.preventBackButton,
    jwtAuthMiddleware.loggedInUserDetails
]);


// use express router
app.use('/', require('./routes/'));

app.listen(port, function (err) {
    if (err) {
        console.log(`Error in running the server: ${err}`);
    }
    console.log(`Server is running on port: ${port}`);
});
